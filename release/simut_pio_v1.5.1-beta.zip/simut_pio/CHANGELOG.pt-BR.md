# Changelog

[English](CHANGELOG.md) | **Português**

Todas as mudanças notáveis do firmware SIMUT.

## v1.5.1-beta (2026-07-19)

### Correção do Modo AP — Toque na Inicialização

- **Removido wake-up SPI do XPT2046** — A transação SPI manual (`0x90`) durante o boot colocava o XPT2046 em power-down com PENIRQ desabilitado (PD0=0). Os bytes de dados no protocolo pipeline herdavam PD0=0, mantendo o PENIRQ permanentemente desligado e impedindo a ativação do modo AP por toque. O circuito de touch-detect do XPT2046 está sempre ativo após power-up — nenhuma inicialização SPI é necessária. Correção: modo AP agora ativa corretamente ao segurar o toque na inicialização.

### Correções de Persistência da Calibração

- **Alterações de calibração agora persistem no reboot** — O caminho de reboot do `commit_all` salva corretamente os dados de calibração. Antes eram perdidos em reboot por watchdog.
- **Evita reescrita do `calib.csv` quando `nChanges==0`** — Evita escritas flash desnecessárias quando não há alterações.
- ** salvamento rápido para sensores sem ROM** — Sem travamento no modo silencioso ao salvar calibração de sensores sem identificador ROM.
- **Alterações de hwId/nome na calibração agora instantâneas** — Mudanças aplicam em 0,4s em vez de exigir reload completo.

### Melhorias no Dashboard & UI

- **Persistência do slot 0 no painel superior** — O slot 0 agora persiste corretamente no painel superior após alterações de offset ou tema.
- **Troca automática do painel inferior** — Quando o slot do painel superior muda, o painel inferior agora alterna automaticamente para o próximo slot disponível.

### Pacotes de Release para Arduino IDE

- **`tools/build_release.sh`** — Script automatizado para gerar `.zip` compatíveis com Arduino IDE para as variantes `simut_tft` (ILI9341) e `simut_alpha` (HD44780).
- **Estrutura de arquivos achatada** — Todos os arquivos na raiz do sketch; includes de subpastas (`ota/`, `display/`, `sensors/`) reescritos para caminhos planos.
- **Ambas variantes compilam com arduino-cli** — TFT: 911.888 bytes (87%), Alpha: 819.636 bytes (78%) no RP2040 Pico W com filesystem de 1 MB.

### Arquivos de Atualização OTA

- **Binários do firmware** — `release/simut_v1.5.1-beta.bin` (atualização OTA) e `release/simut_v1.5.1-beta.uf2` (flash via USB mass-storage).

## v1.5.0-beta (2026-07-19)

### Configuração de Hardware Centralizada — `simut_config.h`

- **Arquivo único de configuração** — Todas as opções configuráveis agora ficam em `src/simut_config.h`: tipo de display, pinos, sensores, Bluetooth, mDNS, pacotes de temas, pino do buzzer e limites avançados. Antes espalhadas por mais de 8 arquivos.
- **9 seções documentadas** — Tipo de display, pinos TFT, pinos Alpha/HD44780 (I2C e paralelo), buzzer, sensores, comunicação, pacotes de temas, pino padrão 1-Wire, limites avançados. Cada opção com comentários explicativos.
- **Guardas `#ifndef` em todas as definições** — Cada define permite override em tempo de compilação via flags `-D` no `platformio.ini`. Os defaults correspondem à configuração de release existente.
- **Retrocompatível** — Headers de configuração antigos (`DisplayConfig.h`, `SensorConfig.h`) delegam ao `simut_config.h`. Todas as cadeias de `#include` preservadas. Sem breaking changes.
- **Suporte a Arduino IDE** — Guarda `__has_include("simut_arduino_config.h")` no topo do `simut_config.h` para pacotes de release. Configs de release simplificadas para definir overrides antes do include.

### Limpeza do Sistema de Build

- **`platformio.ini` desduplicado** — Flags de sensores e features removidos do `[pico_base]` (agora no `simut_config.h`). Apenas overrides específicos por ambiente permanecem no `[env:pico_w_alpha]`.
- **Pacotes de release simplificados** — `release/*/simut_arduino_config.h` agora inclui `simut_config.h` em vez de duplicar todas as definições.

### Correções de Bugs

- **BluetoothManager.cpp** — Adicionado guarda `#if SIMUT_BLUETOOTH` ausente em todas as implementações dos métodos. Previne erros de redefinição quando `SIMUT_BLUETOOTH=0` e o arquivo é compilado (builds debug).
- **HD44780_16x2.h** — Envolvido `_initLcd()` e seu ponto de chamada em `#if HD44780_MODE_PARALLEL`. A sequência de inicialização paralela 4-bit era incorretamente compilada no modo I2C.

### Seleção de Pacotes de Temas

- **Movida para `simut_config.h`** — Pacotes de temas (`SIMUT_THEMES_HEALTH`, `_PRO`, `_MEDICAL`, `_SAFETY`, `_RETRO`, `_NATURE`, `_UTILITY`) agora são habilitados descomentando linhas no arquivo de configuração, não editando `Themes.cpp`.
- **`Themes.h` inclui `simut_config.h`** — Flags de temas são visíveis onde quer que `Themes.h` seja incluído.

### Coexistência de Recursos PIO — Resolução de Conflitos Multi-Sensor

- **Conflito no pio0 identificado** — OneWirePIO (DS18B20, 27 slots de instrução) + WirePIO (BME280 I2C, 32 slots) = 59 > 32 disponíveis. WirePIO carregava primeiro, bloqueando OneWirePIO (DS18B20 morria — sem fallback GPIO).
- **Saturação de SMs no pio1** — 2× DHT22 (2 SMs) + CYW43 WiFi (1 SM) + BuzzerPIO (2 SMs) = 5 > 4 SMs. Resolvido pelo fallback automático do BuzzerPIO para pio0.
- **Correção no `BME280Driver.h`** — Adicionado `forceGPIO(true)` antes de cada `begin()`. BMx280PIO agora usa apenas GPIO bit-bang I2C (sem PIO+DMA), mantendo os slots de instrução do pio0 livres para OneWirePIO. Modo GPIO é um pouco mais lento mas totalmente confiável.
- **`docs/PIO_ANALYSIS.md`** — Análise completa de alocação de recursos PIO cobrindo todas as bibliotecas (OneWirePIO, DHTBus, WirePIO, BuzzerPIO, CYW43), orçamento de slots de instrução por bloco, contagem de state machines, canais DMA, cenários de conflito e mecanismos de resolução.

### Validação em Hardware — Teste de Coexistência com 4 Sensores

Testado no Pico W com display TFT + buzzer + WiFi:

| Sensor | GPIOs | Tipo | Status |
|--------|-------|------|--------|
| BMP280 | GP0 (SDA), GP1 (SCL) | driver BME280 | ✅ Lendo (GPIO bit-bang) |
| DHT22 #1 | GP2 | DHT22 | ✅ Detectado, lendo |
| DHT22 #2 | GP3 | DHT22 | ✅ Detectado, lendo |
| DS18B20 | GP4 | DS18B20 | ✅ Detectado (ROM: 283C21…), lendo |

- **WiFi**: Conectado (RSSI -45 dBm), servidor web respondendo
- **PIO após correção**: pio0 31/32 slots (OneWirePIO + BuzzerPIO fallback), pio1 23/32 slots (DHTBus×2 + CYW43)
- **Heap**: 94,3 KB estável, sem vazamentos após 11+ minutos de operação contínua
- **Leituras**: 857/916 OK (93,2%), 59 erros concentrados na inicialização
- Todos os 4 sensores configurados e ativados via CLI, configuração persistida no flash

### Orçamento de Flash

- **Release (TFT + todos sensores + mDNS)**: 94,1% (982604 / 1044480 bytes)
- **Alpha (HD44780 paralelo + todos sensores + mDNS)**: 85,4% (891920 / 1044480 bytes)
- **RAM (release)**: 35,8% (93760 / 262144 bytes)

## v1.4.4-beta (2026-06-07)

### Gestão de Recursos GPIO — Montagem Guiada de Slots

- **Comando `gpio`** — Mapa de recursos GPIO mostrando todos os 16 pinos com estado de alocação (FREE ou `[Slot XX] Tipo (Função)`), mais uma lista consolidada de GPIOs livres. GPIOs agora são um recurso limitado visível e rastreável.
- **`sensor <slot> create <tipo>`** — Criação guiada de slot. Define o tipo do driver, limpa atribuições de pinos anteriores, ativa o slot e mostra: contagem de pinos, função e flags de cada pino (ex.: `1-Wire (pull-up)`), GPIOs livres disponíveis e uma dica para o próximo comando (`sensor <slot> pin <idx>,<gpio>`).
- **`sensor <slot> type <tipo>`** — Agora mostra os requisitos de pinos e as atribuições GPIO atuais por pino após mudar o tipo, para que o usuário saiba o que conectar.
- **`sensor <slot> pin <idx>,<gpio>`** — Agora mostra o rótulo da função para contexto (ex.: `pin[0]=GPIO 3 (1-Wire)`). Detecta quando todos os pinos necessários estão atribuídos e sugere o próximo passo (`sensor <slot> name "<nome>"`).
- **`sensor <slot> active on`** — Valida pré-requisitos antes de ativar: tipo deve estar definido, driver deve estar compilado e todos os pinos declarados devem estar atribuídos. Reporta exatamente quais pinos estão faltando.
- **`show sensor types`** — Lista drivers de sensores compilados com contagem de pinos, resumo de canais e rótulos de função (ex.: `BME280 | 2 pinos | Temp+Hum+Press | SDA,SCL`).

### Driver BME280 — Temperatura + Umidade + Pressão

- **`BME280Driver.h`** (~9KB flash) — Driver I2C autocontido usando medições em modo forçado. Sem dependência de biblioteca externa (evita Adafruit_BME280 com ~15KB).
- **Máquina de estados assíncrona** — BME_IDLE → dispara medição forçada → BME_WAITING → lê resultados, seguindo o padrão assíncrono do DS18B20/DHT22.
- **Fórmulas de compensação** — Matemática inteira conforme datasheet Bosch BME280 §4.2.3 para temperatura, umidade e pressão. Oversampling ×1 em todos os canais (~9ms por leitura).
- **Renderização no painel TFT** — Temperatura + umidade no dashboard (espelha layout do DHT22), suporte a painel min/max. Pressão disponível via API (canal `CH_PRESS`).
- **Auto-detecção I2C** — Sonda endereços 0x76 e 0x77. Scan de hardware detecta BME280 no barramento I2C ativo.
- **Inicialização GPIO multi-pino** — `gpioInitForRole()` agora chamada para TODOS os pinos declarados (não apenas `pins[0]`). Barramento I2C inicializado uma vez quando o primeiro sensor I2C é encontrado. `ROLE_POWER` padrão para output LOW.

### Diagnósticos Melhorados

- **`show sensors`** — Saída redesenhada: slot, GPIOs, tipo do driver, canais (ex.: `T+H+P`), nome, ROM (1-Wire), HWID, estado de alarme e limites por canal.
- **`show sensor types`** — Drivers disponíveis com contagem de pinos, resumo de canais e rótulos de função dos pinos.
- **`PIN_ONEWIRE_DEFAULT`** — Corrigido aviso de redefinição do pré-processador (8 instâncias eliminadas).
- **Todos os 4 canais inicializados** — Loop `MAX_SENSOR_CHANNELS` define `avgValue` para NAN e `calibrationOffset` para 0.

### Outras Mudanças

- **mDNS habilitado por padrão** — `-DSIMUT_MDNS=1` no platformio.ini. Dispositivo acessível via `http://simut.local`. Custo: ~15KB flash, RAM desprezível.
- **Auto-detecção I2C0/I2C1** — `i2cPeripheralForPins()` seleciona o periférico correto em tempo de execução. Qualquer par de GPIO 0-15 funciona para sensores I2C (sujeito ao hardware).
- **`checkAndAutoHealSensors()`** — Não reporta mais falsos avisos "Sensor ausente" para tipos de sensor não-DS18B20 (DHT22, BME280).
- **Guarda de boot do BME280** — Timeout I2C (50ms) + sonda ACK previne travamento no boot quando BME280 está configurado mas não fisicamente conectado.
- **Suposições de GPIO hardcoded removidas** — `begin()` do DHT22 não referencia mais GPIO 10. Métodos legados do DS18B20 usam o pino do primeiro sensor ativo. Zero acoplamento fixo GPIO-tipo.

### Orçamento de Flash

- **Release (DS18B20 + DHT22 + mDNS)**: 93,1% (972KB / 1044KB) — ~72KB livres
- **Com BME280**: 93,7% (979KB / 1044KB) — ~65KB livres
- **RAM**: 35,7% (~93,7KB / 262KB)

## v1.4.3-beta (2026-06-07)

### Dieta de Flash — 86KB Liberados (97,8% → 91,2%)

- **LEAmDNS desabilitado por padrão** — Envolvido com `#ifdef SIMUT_MDNS`. Habilite com `-DSIMUT_MDNS` nas build_flags quando necessário. Economiza ~196KB de biblioteca do link.
- **Stub do BluetoothManager** — Quando `SIMUT_BLUETOOTH=0` (padrão), a classe inteira é inline no-ops. `BluetoothManager.cpp` excluído da build. `SerialBT` ainda compilado pelo framework mas símbolos não usados são removidos pelo linker.
- **CLI `sensor pin <slot> <índice> <gpio>`** — Atribui GPIOs específicos a slots de sensor com detecção de conflitos entre todos os sensores ativos. Valida faixa GPIO (0-15) e índice de pino (< MAX_SENSOR_PINS).
- **Orçamento de flash**: 91,2% (952KB / 1044KB) — 92KB livres para futuras features.

## v1.4.2-beta (2026-06-07)

### Arquitetura de Entidade de Sensor — Funções de Pino Baseadas em Driver

- **Enum PinRole** — Cada pino GPIO agora tem uma função declarada (`ROLE_DATA`, `ROLE_I2C_SDA`, `ROLE_I2C_SCL`, `ROLE_SPI_MOSI`, `ROLE_SPI_MISO`, `ROLE_SPI_SCK`, `ROLE_SPI_CS`, `ROLE_UART_TX`, `ROLE_UART_RX`, `ROLE_ANALOG`, `ROLE_POWER`).
- **PinRequirement no SensorFormat** — Cada driver declara contagem de pinos, função, rótulo e flags (pull-up, open-drain) via `SensorFormat::forType()`. Sem configuração GPIO hardcoded por tipo.
- **`gpioInitForRole()`** — Auto-configura direção GPIO, pulls e função baseado na função declarada. Substitui blocos de inicialização hardcoded `#if SIMUT_SENSOR_DHT22`.
- **Metadados de pino na API** — `/api/status` agora retorna `pc` (contagem de pinos) e `pr` (rótulos de função: "Data", "SDA,SCL") por sensor.
- **Info de pinos na WebUI** — Tabela do dashboard mostra contagem de pinos + funções ao lado do tipo do sensor (ex.: `DHT22 ⚡1p Data`, `BME280 ⚡2p SDA,SCL`).
- **Adicionar um novo sensor** agora requer apenas um arquivo de driver + entrada `SensorFormat::forType()` — display, API, calibração e inicialização GPIO seguem os metadados automaticamente.

## v1.4.1-beta (2026-06-07)

### Arquitetura Universal de Slots — 16 Slots GPIO

- **16 slots universais de sensor** — `MAX_SENSORS` expandido de 10 para 16, cobrindo GPIO0–GPIO15. Todos os slots agora são uniformes com tipo, hwId, friendlyName, pinos e limites de alarme configuráveis.
- **Sensor ambiente eliminado** — O campo especial `ambientSensor` no `SystemConfig` foi removido. O Slot 10 (GPIO10) agora é um slot universal regular, tratado identicamente aos demais. A convenção `idx: -1` da API é substituída pelo índice de slot padrão `10`.
- **Generalização de canais** — `RuntimeSensor` agora usa arrays `avgValue[4]`, `buffers[4]` e `calibrationOffset[4]` com enum `SensorChannel` (CH_TEMP, CH_HUM, CH_PRESS, CH_LUX). Cada driver declara seus canais via `SensorFormat::forType()`. Adicionar um novo tipo de sensor requer apenas um driver — display, API web e calibração adaptam-se automaticamente.
- **Coluna de tipo na tabela do dashboard web** — Tabela agora mostra o tipo do driver (DHT22/DS18B20) por sensor. Formulário de calibração mostra campos de umidade condicionalmente por sensor baseado na flag `hasHum`.
- **Sistema de alarme unificado** — Máscara de alarme por slot agora cobre todos os 16 slots. As flags separadas `ambTempAlarm`/`ambHumAlarm` foram removidas.
- **Migração de config v16→v17** — Migração automática: `ambientSensor` movido para `sensors[10]`, slots 11–15 inicializados como inativos.

### Correções

- **Travamento no boot após flash** — Eliminadas chamadas `Serial` bloqueantes no caminho de boot (`BLOG`, `LogManager`, `CommandManager`, `SoundManager`). Removido `Serial.ignoreFlowControl(true)` que causava atrasos de 1s por linha de log.
- **Prevenção de stack overflow** — Alocações de `SystemConfig` movidas para heap (`tempConfig`, `encBuf`) para evitar o limite de 4KB de stack do RP2040 com a struct v17 maior.
- **Bluetooth desabilitado** — `SerialBT.begin()` causa hardfault no CYW43 após warm boot (reset via picotool). Bluetooth agora desabilitado para garantir boot confiável. USB Serial + interface Web fornecem funcionalidade equivalente.
- **Correções de JSON na API** — Restauradas chamadas `first = false` e `if (!safeSend(buf))` em `/api/sensors`, `/api/status` e `/api/users` que causavam JSON inválido (vírgulas faltando entre objetos).
- **Calibração na WebUI** — Removido card ambiente duplicado. Todos os sensores renderizados uniformemente com campos cientes do tipo.

### Breaking Changes

- **Formato de config v17** — Layout do `SystemConfig` alterado. Configs v16 são auto-migradas no primeiro boot. Downgrade para ≤v1.3.x requer factory reset.
- **API `/api/sensors`** — Sensor ambiente não mais reportado como `idx: -1`. Slot 10 aparece no array padrão de sensores.
- **Formato de histórico** — `BinaryHistoryRecord` alterado de 28 para 40 bytes. Arquivos `.bin` existentes são incompatíveis.
- **Bluetooth removido** — `SerialBT` desabilitado devido a hardfault no CYW43 em warm boot. Use USB Serial ou interface Web.
- **Formato de sensor no `/api/status`** — Adicionados campos `type` e `ch`. Campo de umidade agora usa `sensorHasChannel()` genérico em vez de verificação hardcoded `TYPE_DHT22`.

## v1.3.0-beta (2026-06-07)

### Display Alpha — Suporte a HD44780 16×2 Alfanumérico

- **Driver dual-mode HD44780** — I2C (mochila PCF8574) e GPIO paralelo 4-bit, selecionável via flags `HD44780_MODE_I2C` / `HD44780_MODE_PARALLEL`
- **Seleção de display em tempo de compilação** — Flags `SIMUT_DISPLAY_TFT` e `SIMUT_DISPLAY_ALPHA` permitem compilar para ILI9341 TFT (padrão) ou HD44780 16×2 (alpha), mutuamente exclusivas
- **Modo I2C** — Usa I2C1 nos GPIO 26 (SDA) / GPIO 27 (SCL), endereço 0x27 (configurável via `HD44780_I2C_ADDR`). Zero conflitos com slots de sensor — todos os 10× DS18B20 + DHT22 disponíveis
- **Modo paralelo 4-bit** — RS=GPIO 16, EN=GPIO 17, D4=GPIO 18, D5=GPIO 19, D6=GPIO 20, D7=GPIO 21. Também zero conflitos com slots de sensor
- **GPIO 0-15 reservados para sensores** — Pinos do display mapeados exclusivamente para GPIO 16+, sem deslocamento de sensores
- **Loop do display alpha no Core 1** — Framebuffer de caracteres com blit(), exibição com alternância automática de temperatura/umidade
- **Exclusão da GFX Library** — Adafruit GFX Library, ILI9341 e XPT2046 excluídos da build alpha via `lib_ignore`. Inicialização SPI e detecção de toque protegidas com `#if SIMUT_DISPLAY_TFT`
- **Clock UART1 preservado** — `uart_init()` chamado no modo alpha (apenas clock, sem takeover de GPIO) para manter marcadores de debug do StorageManager seguros
- **Timeout de skip WiFi** — Builds alpha sem botão de skip por toque têm timeout de 30 segundos para conexão WiFi e evitar travamento infinito no boot
- **Ambiente de build `pico_w_alpha`** — Build limpa com 89,0% flash (929 KB), 34,6% RAM (90 KB). Economiza ~84 KB vs build release

### Correções

- **Loop infinito na calibração de touch** — Protegido com `#if SIMUT_DISPLAY_TFT`; build alpha não tem controlador de toque
- **Conflito de pinos SPI no alpha paralelo** — `SPI.begin()` estava configurando GPIO 16-19 antes da inicialização do HD44780, causando falha de boot no modo paralelo
- **Recuperação de corrupção de armazenamento flash** — `picotool erase` completo resolve partição de filesystem corrompida após flashing repetido

### Documentação

- **WIRING.md** — Reescrita completa com três diagramas de pinagem (ILI9341 TFT, HD44780 I2C, HD44780 Paralelo), tabela comparativa, referência de pinos HD44780 e checklists de montagem para cada modo

## v1.2.1-beta (2026-06-06)

### Painéis de Dashboard Duplos Independentes

- **Arquitetura de painel unificada** — Ambos os painéis usam a mesma função `drawSlotPanel()`. O painel ambiente dedicado (`drawAmbientPanel`) foi eliminado (~280 linhas economizadas).
- **Painel superior: modos fixo/interativo** — Pressionamento longo (1s) alterna entre modo fixo (sensor fixado, estilo normal) e modo interativo (fundo cinza escuro + elementos brancos, segue o seletor de slot para escolher qual sensor fixar).
- **Painel inferior: sempre interativo** — Toque curto alterna apenas min/max. Sempre segue os botões SLOT inferiores.
- **Botão S10** — Adicionado slot 10 (DHT22 ambiente no GPIO 10) à barra de botões inferior. Oculto quando o painel superior está fixado nele.
- **Renderização min/max movida para drivers** — `DS18B20_renderMinMax()` e `DHT22_renderMinMax()` nos respectivos drivers, despachados via `sensorRenderMinMax()`. Primitivas compartilhadas em `SensorDrawing.h` reutilizam ícones existentes.
- **Rastreamento de min/max de umidade por slot** — Arrays de umidade por slot com acumulação em tempo real a cada ciclo do loop.
- **Dados independentes do painel superior** — Campos `topSlot*` no `SystemState` com setters dedicados `setTopSlotData()`/`setTopSlotMinMax()`.
- **Atualizações instantâneas de painel** — Render incremental agora compara campos `topSlot*`. `pullSnapshot()` mantém `topSlotIdx` sincronizado para espelhamento no AppManager.
- **Correção de flash de alarme** — Flash de alarme do painel superior verifica `isSlotAlarming(topSlotIdx)` em vez das antigas flags de ambiente.
- **Correção de cor de borda** — Faixa de conteúdo do modo normal usa `borderColor` em vez de `C_TEXT_SUB` hardcoded.
- **Correção de preenchimento de fundo** — Faixa de conteúdo usa `panelBg` em vez de `C_BG_MAIN` para vermelho de alarme e cinza de seleção corretos.

### Comunidade & Documentação

- **Terceira contribuição da comunidade** 🎉 — Suite completa de documentação em espanhol por [@f-p-0](https://github.com/f-p-0): README.md (337 linhas, PR #66), CONTRIBUTING.md (140 linhas, PR #68) e CODE_OF_CONDUCT.md (39 linhas, PR #68), tornando o SIMUT acessível para usuários hispanofalantes em todo o mundo
- **Segunda contribuição da comunidade** 🎉 — Ambiente de desenvolvimento Docker para que contribuidores possam compilar e testar sem instalar PlatformIO localmente ([@JohnMartin0301](https://github.com/JohnMartin0301))
- **Primeira contribuição da comunidade** 🎉 — Suite de testes HistoryCodec v2 com 672 linhas cobrindo codificação roundtrip, limites de frame âncora, compressão NaN e buffer overflow ([@LorenzoLongaretto](https://github.com/LorenzoLongaretto))

### Orçamento de Flash

| Configuração | Flash |
|---|---|
| Ambos sensores ON | 1030872 (98,7%) |

## v1.2.0-beta (2026-06-06)

### Subsistema OTA — Atualização Completa para v4.6.2

- **F-OTA-BOOTLOOP corrigido** — Loop20 OTA 100% PASS. Causa raiz: deadlock reentrante do LittleFS durante escrita do README.md + inicialização do Core 1 adiada para pós-WiFi + safeReboot usa MMIO idêntico ao applier_reboot.
- **F-RESTORE** — Backup/restore confiável via API (98/100 PASS). Snapshot de configuração preservado através do apply OTA com integridade CRC32. Reescreve atômica do calib.csv com VERSION=epoch.
- **F-RAM-SLIM** — Uso de RAM 49,6% → 33,7% (-41 KB / -16pp). Eliminados graph caches, removidos glifos de fonte não usados, buffers compartilhados.
- **F-TEL-HTTPS-RESILIENT** — Corrige crash+reboot quando servidor HTTPS cai. Heap budget mais conservador para conexões TLS.
- **F-OTA-STAGE-NOBLOCK + F-FLASH-DIET** — Corrige TCP drop durante staging de firmware OTA. Upload não-bloqueante com chunk sizing adaptativo.
- **F-DISPLAY-MARGINS** — `fillMarginsBlack` + override do `fillScreen` no `TftWithOffset` para bordas limpas.
- **F-BOOT-CYW43-CYCLE** — Power-cycle do `WL_REG_ON` sempre no `setup()` para inicialização confiável do WiFi.
- **F-SCREENSHOT-INTEGRITY** — Elimina perda/corrupção de linhas no `/api/screenshot` via leitura multi-amostra com voto majoritário.
- **F-OTA-ADMIN-ONLY** — Endpoints OTA exigem `PERM_FULL_ADMIN`.
- **F-TEL-ADAPTIVE** — Telemetria com vazão adaptativa (dimensionamento de lote apenas no backend).
- **F-UI-OTA-FLOW** — Mensagens de UX para OTA + restore com feedback de progresso.

### Documentação & Ferramentas

- **Glossário** — `docs/GLOSSARY.md` decodificando todas as tags inline (F-\*, BUG-\*, SEC-\*, CON-\*, DOC-\*, REF-\*) usadas nos comentários do código.
- **Limpador de comentários** — `tools/cleanup_comments.py` remove referências de histórico de versão e marcadores de changelog dos comentários para preparação de releases.

### Orçamento de Flash

| Configuração | Flash |
|---|---|
| Ambos sensores ON | 1031464 (98,8%) |
| Apenas DS18B20 | ~1028400 (98,5%) |
| Apenas DHT22 | ~1029500 (98,6%) |
| Ambos OFF | ~1024900 (98,1%) |

### Testes

49/49 testes passando (27 validators + 22 HistoryCodec).

## v1.1.0-beta (2026-06-06)

### Arquitetura de Sensores — Sistema Modular de Drivers

- **Flags de compilação por sensor** — `SIMUT_SENSOR_DS18B20`, `SIMUT_SENSOR_DHT22`, `SIMUT_SENSOR_BME280` no `platformio.ini` permitem desabilitar drivers não usados para liberar flash (DS18B20: -2,7 KB, DHT22: -1,6 KB, ambos: -6,1 KB)
- **Configuração universal de slot** — `SensorRecord` v16 com campo `sensorType` explícito + suporte multi-pinos (`pins[4]`), pronto para sensores I2C, SPI, ADC e UART
- **Drivers organizados** — diretório `src/sensors/` com `DS18B20Driver.h`, `DHT22Driver.h`, `SensorConfig.h`, `SensorHelpers.h`
- **Migração de flash v15→v16** — Atualização automática de schema preservando todas as configs de sensores, detecção de tipo via ROM durante a migração
- **Catálogo SensorPresets** — 130+ formatos de exibição pré-definidos em `sensors/SensorPresets.h` cobrindo 30+ grandezas físicas (temperatura, umidade, pressão, peso, luz, química, elétrica, vazão, etc.)
- **Sistema SensorFormat** — `SensorValueFormat` (unidade, decimais, ícone) + `SensorFormat` (1-3 valores por sensor) + factory `forType()` em `sensors/SensorHelpers.h`

### Display — Renderização de Painel Controlada por Driver

- **Ícones nos drivers** — `sensors/SensorDrawing.h` com ícones procedurais (termômetro, gota, manômetro, lâmpada, régua, tubo, raio, pulso, tubulação, bússola, bandeira, átomo, bateria, etc.) protegidos por flags de compilação
- **Painel renderizado pelo driver** — `DHT22_renderPanel()` e `DS18B20_renderPanel()` cuidam do layout completo (ícones, formatação, unidades) via dispatch `sensorRenderPanel()`
- **Painel de slot agora mostra umidade** — DHT22 em qualquer slot exibe temperatura e umidade com ícone de gota e sufixo traduzido (%UR/%RH)
- **Cores do tema** — Drivers recebem `C_TEXT_SUB`, `C_TEMP_OK`, `C_TEMP_HOT`, `C_HUMIDITY` do tema ativo; ícones acompanham mudanças de tema
- **Posicionamento original exato** — `textAnchor=92`, `iconX=14`, `rightMargin=15` copiados do `drawAmbientPanel` original
- **Formatador genérico** — `formatSensorValue()` em `DisplayManager_FmtFloat.h` trata NaN e casas decimais variáveis

### Correções de Bugs

- **Modo AP via toque no boot** — XPT2046 recebe comando SPI de ativação durante o boot inicial; pino PENIRQ lido diretamente via `gpio_get()`. Janela AP sempre abre independente do estado de settle.
- **Calibração de touch obrigatória no primeiro boot** — Sensibilidade + calibração de 4 pontos executa antes do dashboard quando `magic != 0xCA`. Cancelar durante o boot aplica defaults seguros.
- **Comando `sensor define`** — Sintaxe estendida aceita tipo do sensor: `sensor define <gpio> <rom> <tipo> <hwId> <nome>`. Sintaxe legada de 4 tokens auto-detecta pelo ROM.
- **Comando `sensor accept`** — Define `sensorType` explicitamente nos sensores DS18B20 aceitos.

### Orçamento de Flash

| Configuração | Flash |
|---|---|
| Ambos sensores ON | 1031464 (98,8%) |
| Apenas DS18B20 | ~1028400 (98,5%) |
| Apenas DHT22 | ~1029500 (98,6%) |
| Ambos OFF | ~1024900 (98,1%) |

### Testes

49/49 testes passando (27 validadores + 22 HistoryCodec).

## v1.0.0 (2026-06-03)

### Lançamento Público Inicial

- **Suporte a múltiplos sensores** — Até 16 sensores em slots configuráveis: DS18B20 (1-Wire), DHT22 (Data), BME280 (I2C)
- **Pipeline de sensor zero-trust** — Verificação de ROM, detecção de mismatch de hardware, histerese de erro
- **Display TFT ILI9341 320×240** — Dashboard, gráficos em tempo real, configurações via toque (XPT2046)
- **50 temas integrados** + suporte a temas customizados via LittleFS
- **Servidor web embarcado** — Sessões multi-usuário, RBAC (10 bits de permissão), gerenciador de arquivos
- **WebUI comprimida com gzip** — Páginas inline minificadas com CSS/JS compartilhado
- **Telemetria** — HTTP POST e MQTT com templates JSON/CSV/customizados, TLS/SSL
- **CLI de canal duplo** — USB Serial + Bluetooth (BLE)
- **Sincronização NTP** — Backoff exponencial, fallback multi-servidor, RTC virtual
- **Codec de histórico v2** — Delta + sensor-mask + codificação anchor, ~45% de redução de tamanho
- **Autenticação reforçada** — HMAC-SHA256, salt aleatório por usuário, 5000 rounds
- **Atualização OTA** — Upload via interface web, preservação de snapshot de configuração, auto-reboot
- **Backup e restauração** — Backup/restauração completa do LittleFS com integridade CRC32 (formato BKP1)
- **Perícia de crash** — Autópsia via scratch registers do watchdog com monitoramento cross-core
- **Internacionalização** — Inglês + Português/Espanhol via pacotes de idioma externos
